# Pharo Icon Packs
A repository to keep icon packs for Pharo IDE.

## Idea11 icon pack
This is a derivative from INtelliJ Idea11 icon pack, who are distributed under [Apache 2 licence](http://apache.org/licenses/LICENSE-2.0)
